﻿namespace VideoForms {
    partial class Form1 {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose (bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent () {
            this.panel1 = new System.Windows.Forms.Panel();
            this.SidePanel = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button15 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.userControlFacturaBuena1 = new VideoForms.UserControlFacturaBuena();
            this.userControlEnsaladas1 = new VideoForms.UserControlEnsaladas();
            this.userControlCesta3 = new VideoForms.UserControlCesta();
            this.userControlPollo1 = new VideoForms.UserControlPollo();
            this.userControl21 = new VideoForms.UserControl2();
            this.userControprueba1 = new VideoForms.UserControprueba();
            this.userControl14 = new VideoForms.UserControl1();
            this.userControl13 = new VideoForms.UserControl1();
            this.firstCustomControl7 = new VideoForms.FirstCustomControl();
            this.userControl12 = new VideoForms.UserControl1();
            this.firstCustomControl6 = new VideoForms.FirstCustomControl();
            this.firstCustomControl5 = new VideoForms.FirstCustomControl();
            this.firstCustomControl4 = new VideoForms.FirstCustomControl();
            this.firstCustomControl3 = new VideoForms.FirstCustomControl();
            this.firstCustomControl2 = new VideoForms.FirstCustomControl();
            this.userControl11 = new VideoForms.UserControl1();
            this.firstCustomControl1 = new VideoForms.FirstCustomControl();
            this.userControlCesta1 = new VideoForms.UserControlCesta();
            this.userControlCesta2 = new VideoForms.UserControlCesta();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.Controls.Add(this.SidePanel);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(184, 650);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // SidePanel
            // 
            this.SidePanel.BackColor = System.Drawing.Color.Maroon;
            this.SidePanel.Location = new System.Drawing.Point(0, 60);
            this.SidePanel.Name = "SidePanel";
            this.SidePanel.Size = new System.Drawing.Size(10, 54);
            this.SidePanel.TabIndex = 3;
            this.SidePanel.Paint += new System.Windows.Forms.PaintEventHandler(this.SidePanel_Paint);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(184, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1078, 10);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkRed;
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Location = new System.Drawing.Point(257, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(163, 159);
            this.panel3.TabIndex = 2;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(30, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 21);
            this.label2.TabIndex = 5;
            this.label2.Text = "Restaurante";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(25, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 30);
            this.label1.TabIndex = 3;
            this.label1.Text = "Fast Food";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(426, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(338, 34);
            this.label3.TabIndex = 3;
            this.label3.Text = "c# by Antonio Guerrero";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.userControlFacturaBuena1);
            this.panel5.Controls.Add(this.userControlEnsaladas1);
            this.panel5.Controls.Add(this.userControlCesta3);
            this.panel5.Controls.Add(this.userControlPollo1);
            this.panel5.Controls.Add(this.userControl21);
            this.panel5.Controls.Add(this.userControprueba1);
            this.panel5.Controls.Add(this.userControl14);
            this.panel5.Controls.Add(this.userControl13);
            this.panel5.Controls.Add(this.firstCustomControl7);
            this.panel5.Controls.Add(this.userControl12);
            this.panel5.Controls.Add(this.firstCustomControl6);
            this.panel5.Controls.Add(this.firstCustomControl5);
            this.panel5.Controls.Add(this.firstCustomControl4);
            this.panel5.Controls.Add(this.firstCustomControl3);
            this.panel5.Controls.Add(this.firstCustomControl2);
            this.panel5.Controls.Add(this.userControl11);
            this.panel5.Controls.Add(this.firstCustomControl1);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.Location = new System.Drawing.Point(184, 213);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1078, 437);
            this.panel5.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1075, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 23);
            this.label4.TabIndex = 12;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(469, 100);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(134, 26);
            this.textBox1.TabIndex = 13;
            // 
            // button15
            // 
            this.button15.Image = global::VideoForms.Properties.Resources.shoppingcart_77968__1_;
            this.button15.Location = new System.Drawing.Point(1153, 60);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(77, 74);
            this.button15.TabIndex = 11;
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Transparent;
            this.button13.Image = global::VideoForms.Properties.Resources._1486486303_alert_bell_notification_education_christmas_bell_church_bell_ring_81235;
            this.button13.Location = new System.Drawing.Point(887, 16);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(33, 31);
            this.button13.TabIndex = 9;
            this.button13.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Transparent;
            this.button11.Image = global::VideoForms.Properties.Resources.systemshutdown_103390;
            this.button11.Location = new System.Drawing.Point(190, 16);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(61, 65);
            this.button11.TabIndex = 7;
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click_1);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Transparent;
            this.button10.Image = global::VideoForms.Properties.Resources._1491579542_yumminkysocialmedia22_83078;
            this.button10.Location = new System.Drawing.Point(809, 16);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(33, 31);
            this.button10.TabIndex = 6;
            this.button10.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Transparent;
            this.button9.Image = global::VideoForms.Properties.Resources._1491580635_yumminkysocialmedia26_83102;
            this.button9.Location = new System.Drawing.Point(848, 16);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(33, 31);
            this.button9.TabIndex = 5;
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Transparent;
            this.button8.Image = global::VideoForms.Properties.Resources.social_facebook_box_blue_256_30649;
            this.button8.Location = new System.Drawing.Point(770, 16);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(33, 31);
            this.button8.TabIndex = 4;
            this.button8.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::VideoForms.Properties.Resources._39_85225;
            this.pictureBox1.Location = new System.Drawing.Point(30, 14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(98, 71);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button4.Image = global::VideoForms.Properties.Resources.cherry_122983;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(0, 120);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(187, 54);
            this.button4.TabIndex = 3;
            this.button4.Text = "  Bebida";
            this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Image = global::VideoForms.Properties.Resources.windows_icon_icons_com_62797;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(12, 60);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(175, 54);
            this.button1.TabIndex = 0;
            this.button1.Text = "  Casa";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button5
            // 
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button5.Image = global::VideoForms.Properties.Resources._32395greensalad_98843;
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(0, 300);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(187, 54);
            this.button5.TabIndex = 4;
            this.button5.Text = "  Ensaladas";
            this.button5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Image = global::VideoForms.Properties.Resources._32382hamburger_98925;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(0, 180);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(187, 54);
            this.button2.TabIndex = 1;
            this.button2.Text = " Burger";
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button3.Image = global::VideoForms.Properties.Resources._64_85306;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(0, 240);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(187, 54);
            this.button3.TabIndex = 2;
            this.button3.Text = "  Pollo";
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // userControlFacturaBuena1
            // 
            this.userControlFacturaBuena1.Location = new System.Drawing.Point(-3, 0);
            this.userControlFacturaBuena1.Name = "userControlFacturaBuena1";
            this.userControlFacturaBuena1.Size = new System.Drawing.Size(1078, 437);
            this.userControlFacturaBuena1.TabIndex = 16;
            this.userControlFacturaBuena1.Visible = false;
            // 
            // userControlEnsaladas1
            // 
            this.userControlEnsaladas1.Location = new System.Drawing.Point(3, 0);
            this.userControlEnsaladas1.Name = "userControlEnsaladas1";
            this.userControlEnsaladas1.Size = new System.Drawing.Size(1078, 437);
            this.userControlEnsaladas1.TabIndex = 15;
            this.userControlEnsaladas1.Load += new System.EventHandler(this.userControlEnsaladas1_Load);
            // 
            // userControlCesta3
            // 
            this.userControlCesta3.Location = new System.Drawing.Point(-3, 3);
            this.userControlCesta3.Name = "userControlCesta3";
            this.userControlCesta3.Size = new System.Drawing.Size(1078, 437);
            this.userControlCesta3.TabIndex = 14;
            // 
            // userControlPollo1
            // 
            this.userControlPollo1.Location = new System.Drawing.Point(4, 0);
            this.userControlPollo1.Name = "userControlPollo1";
            this.userControlPollo1.Size = new System.Drawing.Size(1078, 437);
            this.userControlPollo1.TabIndex = 13;
            this.userControlPollo1.Visible = false;
            this.userControlPollo1.Load += new System.EventHandler(this.userControlPollo1_Load_2);
            // 
            // userControl21
            // 
            this.userControl21.Location = new System.Drawing.Point(-3, -55);
            this.userControl21.Name = "userControl21";
            this.userControl21.Size = new System.Drawing.Size(1078, 473);
            this.userControl21.TabIndex = 12;
            this.userControl21.Visible = false;
            this.userControl21.Load += new System.EventHandler(this.userControl21_Load);
            // 
            // userControprueba1
            // 
            this.userControprueba1.Enabled = false;
            this.userControprueba1.Location = new System.Drawing.Point(0, -499);
            this.userControprueba1.Name = "userControprueba1";
            this.userControprueba1.Size = new System.Drawing.Size(1002, 519);
            this.userControprueba1.TabIndex = 11;
            // 
            // userControl14
            // 
            this.userControl14.Location = new System.Drawing.Point(432, 101);
            this.userControl14.Name = "userControl14";
            this.userControl14.Size = new System.Drawing.Size(1074, 519);
            this.userControl14.TabIndex = 10;
            // 
            // userControl13
            // 
            this.userControl13.Location = new System.Drawing.Point(0, 239);
            this.userControl13.Name = "userControl13";
            this.userControl13.Size = new System.Drawing.Size(1102, 508);
            this.userControl13.TabIndex = 9;
            // 
            // firstCustomControl7
            // 
            this.firstCustomControl7.Location = new System.Drawing.Point(73, 127);
            this.firstCustomControl7.Name = "firstCustomControl7";
            this.firstCustomControl7.Size = new System.Drawing.Size(1077, 514);
            this.firstCustomControl7.TabIndex = 8;
            // 
            // userControl12
            // 
            this.userControl12.Location = new System.Drawing.Point(0, 0);
            this.userControl12.Name = "userControl12";
            this.userControl12.Size = new System.Drawing.Size(1053, 479);
            this.userControl12.TabIndex = 7;
            this.userControl12.Visible = false;
            // 
            // firstCustomControl6
            // 
            this.firstCustomControl6.Location = new System.Drawing.Point(0, 0);
            this.firstCustomControl6.Name = "firstCustomControl6";
            this.firstCustomControl6.Size = new System.Drawing.Size(1090, 514);
            this.firstCustomControl6.TabIndex = 6;
            // 
            // firstCustomControl5
            // 
            this.firstCustomControl5.Location = new System.Drawing.Point(0, 0);
            this.firstCustomControl5.Name = "firstCustomControl5";
            this.firstCustomControl5.Size = new System.Drawing.Size(1102, 440);
            this.firstCustomControl5.TabIndex = 5;
            // 
            // firstCustomControl4
            // 
            this.firstCustomControl4.Location = new System.Drawing.Point(0, 0);
            this.firstCustomControl4.Name = "firstCustomControl4";
            this.firstCustomControl4.Size = new System.Drawing.Size(1122, 514);
            this.firstCustomControl4.TabIndex = 4;
            // 
            // firstCustomControl3
            // 
            this.firstCustomControl3.Location = new System.Drawing.Point(0, 0);
            this.firstCustomControl3.Name = "firstCustomControl3";
            this.firstCustomControl3.Size = new System.Drawing.Size(1122, 514);
            this.firstCustomControl3.TabIndex = 3;
            // 
            // firstCustomControl2
            // 
            this.firstCustomControl2.Location = new System.Drawing.Point(0, 0);
            this.firstCustomControl2.Name = "firstCustomControl2";
            this.firstCustomControl2.Size = new System.Drawing.Size(1122, 514);
            this.firstCustomControl2.TabIndex = 2;
            // 
            // userControl11
            // 
            this.userControl11.Location = new System.Drawing.Point(0, 0);
            this.userControl11.Name = "userControl11";
            this.userControl11.Size = new System.Drawing.Size(1053, 479);
            this.userControl11.TabIndex = 1;
            // 
            // firstCustomControl1
            // 
            this.firstCustomControl1.Location = new System.Drawing.Point(0, 0);
            this.firstCustomControl1.Name = "firstCustomControl1";
            this.firstCustomControl1.Size = new System.Drawing.Size(996, 440);
            this.firstCustomControl1.TabIndex = 0;
            this.firstCustomControl1.Load += new System.EventHandler(this.firstCustomControl1_Load);
            // 
            // userControlCesta1
            // 
            this.userControlCesta1.Location = new System.Drawing.Point(-3, -418);
            this.userControlCesta1.Name = "userControlCesta1";
            this.userControlCesta1.Size = new System.Drawing.Size(1078, 437);
            this.userControlCesta1.TabIndex = 14;
            // 
            // userControlCesta2
            // 
            this.userControlCesta2.Location = new System.Drawing.Point(0, 0);
            this.userControlCesta2.Name = "userControlCesta2";
            this.userControlCesta2.Size = new System.Drawing.Size(1078, 437);
            this.userControlCesta2.TabIndex = 15;
            this.userControlCesta2.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1262, 650);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel SidePanel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Panel panel5;
        private FirstCustomControl firstCustomControl1;
        private UserControl1 userControl13;
        private FirstCustomControl firstCustomControl7;
        private UserControl1 userControl12;
        private FirstCustomControl firstCustomControl6;
        private FirstCustomControl firstCustomControl5;
        private FirstCustomControl firstCustomControl4;
        private FirstCustomControl firstCustomControl3;
        private FirstCustomControl firstCustomControl2;
        private UserControl1 userControl11;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label label4;
        private UserControl1 userControl14;
        private UserControprueba userControprueba1;
        private UserControl2 userControl21;
        private UserControlPollo userControlPollo1;
        private UserControlCesta userControlCesta2;
        private UserControlCesta userControlCesta1;
        private UserControlCesta userControlCesta3;
        private UserControlEnsaladas userControlEnsaladas1;
        public System.Windows.Forms.TextBox textBox1;
        private UserControlFacturaBuena userControlFacturaBuena1;
    }
}

